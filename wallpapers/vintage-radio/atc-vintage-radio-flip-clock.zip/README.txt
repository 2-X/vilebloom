A Pen created at CodePen.io. You can find this one at http://codepen.io/tstoik/pen/gaawRR.

 Inspired by this shot: https://dribbble.com/shots/2236793-Vintage-Flip-Clock

I decided to add a radio button because I love any excuse to use some old timey radio

Uses http://avondaletypeco.com fonts