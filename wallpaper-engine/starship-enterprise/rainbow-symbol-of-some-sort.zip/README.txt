A Pen created at CodePen.io. You can find this one at http://codepen.io/towc/pen/gpxgwv.

 a thing that happened when I was trying to make [this other thing](http://codepen.io/MateiGCopot/pen/eNEBQX)