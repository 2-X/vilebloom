A Pen created at CodePen.io. You can find this one at http://codepen.io/ferronsays/pen/nJqzf.

 Pseudo '3D' Planet.  Clouds are flying around using the code from my flocking experiment.