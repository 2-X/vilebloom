A Pen created at CodePen.io. You can find this one at http://codepen.io/mrspok407/pen/ZpBNob.

 I just had to do it sooner or later :)
On september 7 was 50th Star Trek  anniversary.
Live long and prosper.

Based on dribbble shot by Thorsten Beeck https://dribbble.com/shots/2959764-50-Years-of-Star-Trek